﻿using System.Reflection;

[assembly: AssemblyVersion("0.0.0.0")]
