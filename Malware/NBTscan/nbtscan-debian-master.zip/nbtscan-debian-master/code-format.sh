clang-format -i src/*[ch]
